print(type(None))
print(type(True))
print(type(False))
print(type(1))
print(type(1/3))
print(type('123'))


s = 'JKDKnsahjasi2mewl'
print(s.lower())
print(s.upper())
s = s + 'pqwe'
print(s)


numbers = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'hello', [1, 2, 3]]
print(type(numbers))
print(numbers[-1][0])
print(numbers[:10])
numbers.append(numbers[:2])
print(numbers)

users = [
    {'first_name': 'Jack', 'last_name': 'Black', 'age': 100},
    {'first_name': 'Mary', 'last_name': 'Jane', 'age': 40}
]

print(users[0]['age'])

users[0]['rate'] = 9.7

print(users[0])