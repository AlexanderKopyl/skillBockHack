import requests
print(requests.get('https://google.com/').status_code)
