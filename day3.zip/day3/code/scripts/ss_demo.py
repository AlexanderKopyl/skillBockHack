alphabet2 = '01'
alphabet10 = '0123456789'
alphabet16 = '0123456789ABCDEF'


1000

8 14 3

'8D3'
